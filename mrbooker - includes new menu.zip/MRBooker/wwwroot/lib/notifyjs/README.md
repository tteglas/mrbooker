Notify.js
=====

> A simple, yet fully customizable notification library

See demos and full documentation at:

## https://notifyjs.com/

----

Notify.js is released under the [MIT License](https://opensource.org/licenses/MIT).

Copyright © Jaime Pillora &lt;dev@jpillora.com&gt;
