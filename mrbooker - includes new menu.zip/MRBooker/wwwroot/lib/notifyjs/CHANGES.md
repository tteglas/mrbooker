2015-10-20	v0.4

	@EvanCarroll - Updated to remove Grunt, and coffeescript stuff, changed to use UMD.
	@jpillora - Remove deprecated grunt file, there is now a single `notify.js` file
